.. jaconv documentation master file, created by
   sphinx-quickstart on Sat Jun  2 01:28:00 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to jaconv's documentation!
==================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   jaconv

